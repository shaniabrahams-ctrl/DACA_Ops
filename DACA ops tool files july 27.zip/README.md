# DACA Ops — process redesign, session outputs

Working session with Shani (DACA owner). Goal: make the DACA ops tool usable by a rep
who knows **nothing** about DACA — accurate, guided operational flow. Focus is process +
UX, not colors. We walked **one stage at a time** and stopped at intake; downstream is
intentionally parked.

Source repo this was built against: `shaniabrahams-ctrl/DACA_Ops` @ branch
`claude/nifty-darwin-rle1pt` (read from a fresh clone — the live working tree may be
newer; always trust the running code over file descriptions in these docs).

---

## What's in this folder

| File | What it is | Status |
|---|---|---|
| `PROCESS_REDESIGN_NOTES.md` | The full decision log — every choice, correction, and locked principle, in order. The source of truth for *why*. | Living |
| `CLAUDE_CODE_PROMPT_intake.md` | Paste-in prompt for Claude Code: implement the two Slack notifications + net-new detection + confirm-to-create Jira. **Run this first.** | Ready |
| `CLAUDE_CODE_PROMPT_case_ui.md` | Paste-in prompt for Claude Code: surgical case-page UI (your-move verdict, connect done→advance, origin line, reconcile Jira button). Depends on the intake change. | Ready |
| `mockup_slack_notifications.html` | Visual of Ping A (clean + ambiguous) and Ping B, in Slack style, real Harmonate data. | Reference |
| `mockup_stage1_inquiry_v2.html` | Visual of the intake case card (one move, constraints as reference, ambient automation strip). Uses real app tokens. | Reference |
| `mockup_stage1_inquiry.html` | First draft of the intake card — **superseded by v2** (too many tasks). Kept for contrast. | Superseded |
| `reshaped_pipeline.html` | Diagram of fraud/redline as parallel tracks vs. the main path. | **PARKED** — see below |

The mockups are design references for the prompts, not code to ship. Open the `.html`
files in a browser (they support light/dark).

---

## Decided & ready to build (intake stage only)

1. **One funnel.** Every request routes through a CS reply that CCs `daca@rho.co` (a
   Google Group of internal DACA stakeholders). That CC is the universal capture point;
   channel (phone/email/web) and Zendesk are just an origin label.
2. **Net-new detection.** Clean signal → auto-open case + Ping A (informational, no
   button). Ambiguous → do NOT act; post a confirm-ping and wait. (No-infer.)
3. **Rep's one intake move:** send the client the **DACA Application Form**. Constraints
   (Springing-only, checking-only, no redlines) are reference, not tasks — CS usually
   already stated them.
4. **Ping B on Typeform submit** (detected as a new row in the Typeform responses
   source): posts a fraud-review request to `#csfraud` (parallel, non-blocking, linked
   so the rep can check it) and **auto-drafts** a Jira ticket the rep **confirms** to
   create — from Slack or the app, idempotent.
5. **One case can span multiple Zendesk tickets** (follow-ups cross-link); merge to one
   register case.

## Standing principles (apply everywhere, not just intake)
- **Rep decides.** When the fork is tool-acts vs. rep-chooses, surface the situation +
  evidence and let the rep choose. Auto-act only on clean, unambiguous signals.
- **No-infer.** Unknown fields show "not provided" — never a guess. Entity/lender/account
  are never inferred from an email.
- **Human touchpoints are approvals, not corrections.** If the tool forces a manual fix,
  that's a bug. Internal notifications/drafts = automatic; outward/irreversible actions
  (client email, Webster send, DocuSign, live Jira create) = draft-then-human-confirm.
- **Idempotent.** Re-running or re-clicking never duplicates a case, ping, or ticket.

---

## PARKED — do not build yet

- **Fraud/redline as parallel tracks** and the **7-step reshaped pipeline**
  (`reshaped_pipeline.html`). This implies editing `lifecycle.py` stages + transition
  rules (the "load-bearing" state machine). It's likely the *right* change — the current
  `inquiry → fraud_review → templates_sent` order does not match observed reality
  (fraud runs in parallel; templates often go out first) — but it's a process-model
  rework, not a refinement, and Shani flagged we were getting ahead. Revisit only when we
  walk to those stages. See notes D4/D5 and the "don't get ahead" entry.

## Not yet walked (future stages)
Send-template (+ "already sent?" guard via thread text / attachment scan, and doc-version
currency), align + collect signatory info (name/title/email for entity + lender),
compliance package, **DocuSign ordered sequencer** (Borrower → Lender → Rho CFO → Webster
— the highest-risk step), account setup, active. Real downstream context captured from
Zendesk #265034; see notes.

---

## How to use these

1. Run `CLAUDE_CODE_PROMPT_intake.md` in Claude Code. It tells the session to read the
   real files, confirm the `typeform_client.py` path and `slack_notify.py` structure, and
   show test output for 5 done-criteria before claiming done.
2. Then run `CLAUDE_CODE_PROMPT_case_ui.md` for the case-page UI. It depends on the
   staged-draft Jira backend from step 1; if that isn't present, it's told to leave the
   Jira button alone and report back rather than invent a second create path.
3. Keep `PROCESS_REDESIGN_NOTES.md` as the running decision log for the next session.

## Open items still to confirm with Shani
- Canonical name reconciliation in older docs ("DACA request application" → "DACA
  Application Form" is the client-facing term).
- Dedupe key precision (domain vs. legal entity vs. contact) when wiring real
  Gmail/Zendesk data.
- Whether "align + collect signatories" is one step or three (from the real #265034 email
  it reads as: parties align → internal review → request signatory info → DocuSign).
