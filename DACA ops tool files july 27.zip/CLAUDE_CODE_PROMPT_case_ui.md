# Claude Code prompt — DACA Ops case page (intake-stage UI)

Paste everything below the line into the Claude Code session. This is a SEPARATE,
smaller change from the intake-notifications prompt — run that one first if you haven't.

---

Read `docs/DESIGN_BRIEF.md`, then open `src/webapp/templates/case.html` and
`src/webapp/templates/base.html`. This is a UI/UX refinement of the case page for the
intake stage. Preserve all functional behavior and all existing form POST endpoints
(`/advance`, `/resolve`, `/reply`, `/note`, `/create-ticket`). Do NOT touch
`src/register/lifecycle.py`. Use only the CSS variables and component classes already
defined in `base.html` (`.card`, `.btn`, `.btn.secondary`, `.pill`, `.pill.ok`,
`.stepper`/`.step`, `.thread`/`.bubble`, `.ext`, `.muted`, `.small`, and the `--*`
tokens). Do not introduce a new color system.

IMPORTANT: most of what this change needs ALREADY EXISTS in `case.html`. This is
restructure-and-connect, not build-new. Before writing anything, read the file and
confirm each item below against what's actually there — tell me if any assumption is
wrong.

## Goal
Make the case page answer, for a rep who knows nothing about DACA, three questions at a
glance: (1) is this my move or am I waiting on someone, (2) what is the ONE thing to do
now, (3) how do I know when it's done. The content for all three already exists in the
"Guided next step" card (`guide.owner`/`guide.do`/`guide.done`/`guide.macro`); the work
is surfacing and connecting it.

## Changes (surgical)

1. **"Your move" verdict at the top.** Near the H1/stage pills, add a single prominent
   indicator derived from whose turn it is. The guide already carries an owner
   (`guide.who`). Show "YOUR MOVE" (accent/`--ok-bg`) when the owner is the DACA rep,
   or "WAITING ON {owner}" (muted/`--warn-bg`) when it's someone else (Fraud, Legal,
   Compliance, client, Webster). If you need a reliable rep-vs-other signal rather than
   parsing `guide.who` text, add a small server-side `owner_is_rep` boolean to the guide
   context in the view that builds this page — tell me first if so; that's a Python
   change, keep it minimal.

2. **Connect "done" to "advance" (this is the main fix).** Today the guide card shows
   `guide.done` as green "Advances when…" text, while the separate "Advance stage" card
   lets the rep move to any stage via a free dropdown with no gate. Connect them: the
   advance action for the CURRENT stage should visibly reference the `done` condition the
   rep is affirming (e.g. a required "I confirmed: {{ guide.done }}" checkbox, or surface
   the done text directly above the Advance button). Keep the free-stage dropdown
   available as an override for corrections (it's needed for off-pipeline/backwards
   moves), but the primary/next-stage advance should require confirming the done
   condition. Do not remove the existing `/advance` or `/resolve` endpoints or the
   correction path.

3. **Origin context, compact.** The intake origin (Zendesk ticket #, channel, CS rep,
   "daca@rho.co on thread") is available via the "Client comms" card
   (`comms.thread.ticket`). Surface a one-line origin summary near the top so the rep
   sees how the case arrived and who in CS is already involved, without scrolling to the
   comms card. Read-only; do not duplicate the reply composer.

4. **Reconcile the Jira-create button with the intake decision.** The guide card
   currently has a `＋ Create DACA Jira ticket` button posting to `/create-ticket` (an
   immediate create on click). The agreed intake flow is: on Typeform submission the tool
   auto-DRAFTS a Jira ticket and posts a Slack confirm (Ping B); the rep CONFIRMS to
   create — from Slack or the app — and the create is idempotent. Reconcile: this in-app
   button should be that same confirm-a-staged-draft action (idempotent, same result as
   the Slack button), not a second independent create path. If the staged-draft backend
   doesn't exist yet (it's built in the notifications change), leave the button behavior
   as-is but tell me — don't invent a second create path.

## Guardrails
- Preserve every existing endpoint and the human-approval language on the reply composer
  ("Reviewed and sent by a human, never automatically.").
- No new CSS colors; reuse tokens/classes from `base.html`.
- Don't remove the correction/override affordances — a rep must still be able to fix a
  wrong stage.
- Keep the append-only Timeline, Sources, Set-next-action, and Parties cards intact.

## Definition of done (show me, don't assert)
1. Load the case page for an `inquiry`-stage case (e.g. Harmonate) → "YOUR MOVE" shows,
   the one action is clear, origin line renders from the Zendesk ticket.
2. Load a case whose guide owner is Fraud/Legal/client → "WAITING ON …" shows instead.
3. The next-stage advance requires confirming the `done` condition; the free-dropdown
   correction path still works.
4. Page renders in both light and dark (tokens already support both).
5. No endpoint removed; `./run_local.sh` serves the page without template errors.

Start by reading `case.html` and `base.html` and telling me which of the 4 changes are
pure-template vs. need a small view/context change, and flag anything above that doesn't
match the real code before implementing.
