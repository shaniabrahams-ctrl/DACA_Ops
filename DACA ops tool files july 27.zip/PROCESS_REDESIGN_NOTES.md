# DACA Ops — process-flow redesign working notes

Source of truth: /tmp/DACA_Ops @ branch claude/nifty-darwin-rle1pt
Goal (from Shani): a Rho ops rep who knows NOTHING about DACA can run the process
end-to-end, accurately. Focus = operational flow, not colors/skin.

## Locked design principles (carry into every stage)
- PRESERVE (load-bearing, not up for redesign): register/merge logic, the state
  machine + transition rules, no-infer behavior, human-approval gates on
  outward/irreversible actions, source identifiers, plain-English UI.
- Human touchpoints are APPROVALS, not corrections. A required manual fix = a tool bug.
- Internal register updates + ops notifications = automatic. Outward/irreversible
  (client email, Webster send, DocuSign, live Jira create) = draft-then-human-send.

## Five recommendations from the review (the spine of the redesign)
1. Lead each case with a "Your move / Not your move" verdict (derived from `who`).
2. Make "done" a checklist GATE, not a label (advance disabled until confirmed).
3. DocuSign = guided ordered sequencer (Borrower→Lender→Rho CFO→Webster), not a bullet.
4. Board split by OWNERSHIP: "What needs you" = your-move only; waiting cases separate,
   with the blocker + named person.
5. Name the person, not the team (Sam Davidson/Vladan/Mike Szarowicz/Melissa Santos).
   -> verify names against rho-org-structure before shipping.

## Structural caution
Automate the notification + the draft; GATE the confirmation. Rep never types status
back in, but DOES confirm "yes, the external thing happened" — that's the only signal
the tool has that a waiting stage ended. Don't design that confirmation away.

## The 9-step lifecycle (+ off-pipeline)
inquiry -> application_received -> fraud_review -> templates_sent -> (redline_review)
-> compliance_review -> docusign -> final_setup -> active
off: terminated / canceled / rejected / on_hold / closed_unreconciled

## Decisions log (fill as we walk)
- (none yet)

---

## STAGE 1 — INQUIRY / INTAKE  (walking now)

### Correction from Shani (2 front doors, not 1)
A Rho client requests a DACA from ONE of two places:
  1) Email to daca@rho.co
  2) An inquiry to the Client Service team via Zendesk (CS loops in / a ticket exists)

### Code reality (gap)
- src/register/intake_email.py models ONLY the email path. It creates an
  `EMAIL-<slug>` case at stage `inquiry` with a `new_email_intake` flag.
- Zendesk is currently just an optional `zendesk_url` field hanging off an email
  thread — NOT a first-class intake source. A Zendesk-origin request with no
  daca@rho.co email would not create a case today.
- schema `events.source` enum today: 'all'|'gsheet'|'jira'|'salesforce' (no
  'zendesk' / 'email' as intake origins in that list).

### Implication for the novice
The rep must be able to see WHERE a request came from and WHAT that means for their
first action, because the two doors imply slightly different first moves:
  - Email door: reply-all introducing the DACA team on the existing thread.
  - Zendesk door: respond in the Zendesk ticket (client-comms is Zendesk+Gmail);
    CS may already be on it — rep shouldn't double-contact.
Both converge to the SAME step-1 goal: send the DACA request application (Typeform),
state Springing-only + checking-only, recommend a net-new account.

### Open question for Shani (asked)
- Does a Zendesk-origin request always also generate/So we want a `ZENDESK-<id>`
  case id parallel to `EMAIL-<slug>`? And should intake dedupe when the SAME client
  comes via both doors (email + zendesk) so we don't open two cases?

### Shani's answers (intake) — DECISIONS
1. daca@rho.co is ALWAYS on the thread. When a request enters via Zendesk, the CS rep
   responds to the client and CC's daca@rho.co. Reason: daca@rho.co is a Google Group
   with the full set of internal Rho DACA stakeholders — ALL DACA comms must include it.
   => daca@rho.co is the universal capture point. Every request is visible via that
      inbox regardless of which door it came through.
2. Same client via both doors => MERGE into one case (dedupe by client).

### Design consequences (locked)
- INTAKE MODEL: one funnel, keyed on the daca@rho.co thread. "Origin" (email vs.
  zendesk) is a LABEL on the case, not a separate pipeline. Because CS always CCs
  daca@rho.co, the email-intake path already captures Zendesk-origin requests too —
  so the existing intake_email.py is the right backbone; we ADD an origin label +
  (if present) the zendesk ticket deep-link, rather than building a second intake.
- DEDUPE: one case per client/thread. If a zendesk ticket AND a direct email map to
  the same client, they resolve to ONE case (merge). Need a stable dedupe key:
  candidate = normalized client entity/domain + open-request window. (No-infer: if we
  can't confidently match, flag for the rep rather than silently merging.)
- NOVICE UI: intake card shows an "Origin: Zendesk (CS: <rep>) · daca@rho.co thread"
  chip so the rep knows CS is already talking to the client and must reply ON THE
  EXISTING THREAD (keep daca@rho.co CC'd), not start a new one.

### Still to confirm later (not blocking)
- Dedupe key precision (domain vs. legal entity vs. contact) — revisit when we wire
  real Gmail/Zendesk data; for now: match, else flag.

### Shani feedback on Stage-1 mockup (SIMPLIFY) + 2 automation rules
- The mockup OVER-COMPLICATES the start. The two struck-through checklist items
  ("Introduce the DACA team on the thread" and "Recommend a net-new account") are
  noise at intake. Trim the intake card to the essential move, not a 4-item chore list.
- Zendesk: Claude CANNOT read the ZD ticket (rho7005.zendesk.com/.../264554) — no
  connector, no creds. Work from pasted content only. Do not fabricate ticket data.

AUTOMATION RULE A — new-request detection + notify (INTERNAL, auto, not gated):
  Once daca@rho.co is CC'd on an email, the tool must DECIDE if it's a NET-NEW request
  and, if so, auto-post a notification to the #daca-ops Slack channel.
  (Consistent with handoff: internal ops notifications are the tool's job, not human-gated.)

AUTOMATION RULE B — auto-open Jira on Typeform submit (INTERNAL, auto):
  Trigger to create the DACA Jira ticket = the CLIENT SUBMITS THE DACA TYPEFORM RESPONSE.
  That submission is the signal that moves inquiry -> application_received AND fires
  the ticket creation. (Earlier I'd modeled create-ticket as a manual one-click on the
  application_received card; Shani wants it auto on Typeform submit.)
  NOTE vs. handoff #7: handoff lists "a live Jira create" as an outward/irreversible
  action to human-GATE. Reconcile: is auto-create OK because Jira is INTERNAL tracking
  (not client/Webster-facing)? -> ASK. Leaning: internal Jira create can be auto since
  it's not outward-facing to client/bank, but confirm with Shani.

REVISED intake step (novice): the card should really only assert ONE thing —
  "Send the client the DACA request application (Typeform)" — with the origin context
  as a small line, not a callout block. Everything else (net-new detection, Slack ping,
  Jira open) happens automatically behind the scenes.

### REAL EXAMPLE — Zendesk #264554 (Harmonate / Austin Walkup) — from pasted PDF
Ground truth for the intake stage. Timeline (all 2026-07-20):
- 2:48pm  Inbound PHONE call (not email/web) — Austin Walkup, Harmonate, awalkup@harmonate.com.
          Received via = "Inbound phone". Requester called +1 855-743-8746.
- 2:52pm  Marie Solovi (CS Associate) takes inbound call, 4m7s.
- 2:57pm  Marie emails Austin (the client-facing kickoff). KEY: she CC's the DACA
          team on THIS email → CCs = Shani Abrahams <shani.abrahams@rho.co>,
          Bryan DeMaria <bdemaria@harmonate.com>, Rho DACA <daca@rho.co>.
          => THIS is the daca@rho.co CC event that should trip net-new detection.
          Marie's email already states: Springing DACAs only, eligible ACTIVE clients,
          Rho CHECKING accounts.
- 2:57pm  Marie logs an internal-note summary (Business Name: Harmonate; Client: Austin
          Walkup; Request: inquire re DACA; Outcome: looped DACA team; Status: Solved).
- 3:34pm  Austin asks for an ETA.
- 3:42pm  Marie: DACA team will follow up in a few business days; setup ~1–2 weeks.
- 4:16pm  Shani (DACA specialist) sends the REAL step-1 message: introduces self,
          asks client to complete the "DACA Application Form" (hyperlinked), states:
            • Springing DACAs only, no fully-blocked
            • Rho + banking partner DO NOT allow redlines to the standard template
          and previews next step (share standard Springing template for client+lender review).

### What this teaches the redesign
1. ORIGIN nuance: "Zendesk" origin here really began as an INBOUND PHONE call that CS
   logged in Zendesk. So origin label should be the Zendesk ticket + channel
   ("phone", "web", "email") — not assume it was a client email. Show ticket #264554.
2. The daca@rho.co CC event = Marie's 2:57pm email. That is the exact trigger for
   Automation Rule A (net-new detect + Slack ping). Net-new signal is strong here:
   subject "DACA Inquiry", body says "establishing a DACA", no existing case for Harmonate.
3. CS (Marie) already told the client the two constraints. So when the DACA rep (Shani)
   picks it up, repeating "Springing only / checking only" is somewhat redundant for the
   CLIENT but the REP still needs to know it. => In the novice card, constraints are
   REFERENCE (what's true), the ACTION is just: introduce + send the application form.
4. Shani's real 4:16pm message names the redline rule too ("no redlines to standard
   template") — stated earlier than my playbook had it (playbook put redline eval at
   templates_sent). Real practice: set the no-redline expectation at INTAKE. Worth
   reflecting in the guide copy.
5. Terminology in the wild: the client-facing artifact is called "DACA Application Form"
   (Shani) — playbook insists on "DACA request application". Minor mismatch to reconcile:
   which exact name is canonical? (ASK / low priority.)
6. Client entity = "Harmonate" (business name), contact Austin Walkup (COO-type), lender
   NOT yet known (no-infer: leave lender blank, this is why the application form is needed).
   Case id would be e.g. ZD-264554 or EMAIL-HARMONATE — dedupe to ONE.

### Correction to my Stage-1 mockup
- The struck-through items were right to cut. Real step-1 rep action ≈ ONE move:
  "Introduce yourself + send the DACA Application Form (Typeform)." Constraints are a
  reference line, not tasks. Origin = "Zendesk #264554 · phone · CS: Marie Solovi".

### DECISIONS (intake automation) — locked
D1. Jira create on Typeform submit = AUTO-DRAFT + GATE (reconciles with handoff #7).
    Flow: client submits Typeform -> tool posts a notification to #daca-ops Slack AND
    stages a drafted Jira ticket -> the rep clicks CONFIRM to actually create it, either
    in the app OR from Slack (Slack action button). So two Slack pings exist:
      - Ping A: net-new request detected (daca@rho.co CC'd) — informational/auto.
      - Ping B: Typeform submitted — carries the "Confirm & create Jira ticket" action.
D2. Net-new detection: confirm-when-unsure. Clean signals (subject/body = DACA request,
    no matching open case) -> auto-create case + Ping A. Ambiguous -> DO NOT act; surface
    a "possible new request — confirm?" instead. No silent guessing (no-infer).
D3. Canonical client-facing name = "DACA Application Form" (matches what CS/rep actually
    send). Update playbook copy from "DACA request application" -> "DACA Application Form".
    (Keep a note that older docs used the other name.)

### Slack as a second surface (new requirement surfaced by D1)
The rep can act from Slack, not just the app. Ping B needs an actionable button
("Confirm & create Jira ticket"). This is the handoff's R13 "Slack action bot" territory.
Design implication: the CONFIRM action must be idempotent and produce the same result
whether clicked in-app or in Slack (one ticket, logged event, no dupes).

### REAL EXAMPLE cont. — Zendesk #265034 (Harmonate) — the follow-up ticket
This is a NEW ticket (#265034) that is a follow-up to #264554. Note: Zendesk spun a
SEPARATE ticket for the follow-up, cross-referenced ("follow-up to your previous
request #264554"). Same CCs incl. daca@rho.co. Now: Business = "Harmonate Corp."
Timeline:
- Jul 21, 3:31pm  Shani emails Austin: "Thank you for completing the DACA Application
  Form." => THE TYPEFORM IS ALREADY SUBMITTED between #264554 (Jul 20) and now.
  Shani ATTACHES the Springing DACA template (link:
  Rho+Springing+DACA+Template+(10.24.25).pdf) for client + lender to review.
  Reiterates: NO redlines/edits to the standard template.
  Previews the NEXT steps explicitly:
    "After we receive confirmation that all parties are aligned, and our internal
     review is complete, we'll request the signatory information (Name, title, email)
     for both your entity's signatory and the lender's signatory) and issue the
     agreement via DocuSign for execution."
- Jul 21, 3:39pm  Kyle Steadman internal note: "Shani comming to clients - No CS action
  required" (CS explicitly stepping back; DACA DRI owns it now).

### BIG structural correction to the playbook (templates BEFORE fraud, and merged steps)
My playbook order was: inquiry -> application_received -> FRAUD_REVIEW -> TEMPLATES_SENT
-> compliance -> docusign...
Real observed order (Harmonate): intake -> client completes Application Form -> Shani
IMMEDIATELY sends the Springing DACA template (3:31pm) for client+lender review.
=> In practice the template goes out RIGHT AFTER the application, NOT after a fraud gate.
   Either (a) fraud review is not a hard blocker before templates for this path, or
   (b) fraud happens in parallel / earlier via standard onboarding. NEED TO CONFIRM
   with Shani where fraud actually sits. This matters a lot for the "your move / waiting"
   logic — if fraud isn't a blocking wait-stage here, I shouldn't design a big "waiting
   on Fraud" gate into the main path.

Also note the template attachment is a REAL versioned doc:
  "Rho Springing DACA Template (10.24.25)" — matches skill's "10.24 template".
  Doc-currency matters (daca-doc-currency skill): the rep must send the CURRENT template.

### Another terminology/step detail
Shani's email pre-states the DocuSign signatory-collection step: she will later request
"Name, title, email" for BOTH the entity's signatory and the lender's signatory. This
is the data the DocuSign sequencer (rec #3) needs. So signatory capture is its own
sub-step before docusign.

### QUESTION FOR SHANI (blocking the stage-order design)
Where does FRAUD review actually happen for a normal client like Harmonate? Options:
  (a) Before templates go out (my current playbook) — a real blocking wait.
  (b) In parallel / already done via standard Rho onboarding (client is already active),
      so templates go out immediately and fraud isn't a separate blocking stage here.
  (c) Only for prospects/new clients, skipped for existing active clients.

### DECISIONS (fraud + templates) — locked, MAJOR
D4. FRAUD IS NOT A BLOCKING GATE. It runs in PARALLEL. Mechanics:
    - Tool detects the client submitted the Typeform = a NET-NEW ROW appears in the
      Typeform responses sheet (source of truth for "submitted"). Detect by new row.
    - On that submission: post the ticket into the "csfraud" chat and ASK the fraud
      team to do their review. (Parallel side-task, not a stop-the-line stage.)
    - The main flow CONTINUES; the DACA rep can send the template without waiting on fraud.
    - For some clients the template even goes out AHEAD of fraud review.
    => DESIGN: do NOT model fraud as a "Not your move / waiting on Fraud" main-path stage.
       Model it as a PARALLEL TRACK / side-status ("Fraud review: requested / cleared")
       shown as a chip, not a pipeline stop. The rep's main move after submission is
       SEND THE TEMPLATE.

D5. STAGE COLLAPSE. The real main path is:
    inquiry -> application submitted -> SEND TEMPLATE (client+lender review) -> ...
    fraud_review is no longer a sequential main-path stage; it's a parallel checklist item.
    (Keep fraud as tracked side-status so nothing is lost, but it doesn't gate advance.)

D6. TEMPLATE SEND — "already sent?" guard (novice-critical):
    Default = OK to send the template (even again). BUT the tool should FLAG if the
    template was already sent earlier in the comms, so the rep doesn't double-send.
    Detection (either/both):
      - text analysis of prior thread comms (look for template-sent language), and/or
      - attachment scan of the current thread (look for a "Rho Springing DACA Template"
        PDF already attached). src/context/sources/attachment_scanner.py likely relevant.
    Behavior: not a hard block — show "Looks like the template was already sent on
    <date> (found: <evidence>). Send again?" -> rep decides. No-infer: show the evidence,
    let the human confirm.

### Template doc currency (tie-in)
The real attachment was "Rho Springing DACA Template (10.24.25)". The tool must offer
the CURRENT template version (daca-doc-currency skill). Flag if the version on the
thread is stale vs. the current template.

### Post-template preview (from Shani's real email) — future stages, captured now
Shani's #265034 email pre-states the downstream: after all parties align + internal
review, tool/rep requests SIGNATORY INFO (name, title, email) for BOTH the entity
signatory AND the lender signatory, then issues via DocuSign. => signatory capture is a
discrete sub-step feeding the DocuSign sequencer (rec #3).

### Zendesk behavior learned
Zendesk spun a NEW ticket (#265034) for the follow-up, cross-linked to #264554. So one
DACA case spans MULTIPLE zendesk tickets. Case dedupe/merge must group tickets by the
follow-up linkage + same client, into ONE register case. (Reinforces earlier merge rule.)

### PROCESS NOTE (Shani): don't get ahead — we are STILL at the first stages.
The reshaped-pipeline / state-machine rework (D4/D5 above) is PARKED as a downstream
idea, NOT to be acted on now. Do not touch lifecycle.py. Do not design later stages yet.
Stay on intake. Walk one stage at a time, confirm, then move.

Where we actually are: STAGE 1 (intake) — the client inquiry -> rep sends the DACA
Application Form. Fraud/templates/downstream = not yet. Revisit D4/D5 only when we
walk to them.

### SLACK NOTIFICATION DRAFTS (intake stage) — design
Two pings to #daca-ops (per D1/D2):

PING A — net-new inquiry detected (informational, auto, NO action button)
  Trigger: daca@rho.co CC'd on a thread + clean net-new signal (no matching open case).
  Purpose: "a new DACA request just landed, here's who/what, go say hi."
  Fields (all from the CC'd email/ticket, verbatim; no-infer):
    - Business/entity name (as stated; flag if only a domain guess)
    - Client contact (name + email)
    - Origin (zendesk #, channel, CS rep) OR direct email
    - When it arrived
    - Link to the thread + link to the case in the tool
  Tone: short. It's an FYI. The rep's move (send Application Form) is in the app.
  NO confirm button — case already opened automatically on clean signal.
  (If AMBIGUOUS instead of clean: different message — "possible new request, confirm?"
   WITH a confirm button. That's the D2 unsure path. Show both variants.)

PING B — Application Form submitted (actionable, has CONFIRM button)
  Trigger: new row in the Typeform responses sheet matched to this case.
  Purpose: "client finished the form; fraud review kicking off; confirm to open Jira."
  Fields:
    - Business/entity + contact
    - "Application Form submitted <when>"
    - What the tool has already done: fraud review posted to #csfraud (parallel)
    - What it's staging: a drafted DACA Jira ticket
  Action button: [Confirm & create Jira ticket] (idempotent; same result in-app or Slack)
  Secondary: [View application] [Open case]
  Note: this is the human-gate gate on the Jira create (reconciles handoff #7).

Guardrails to show in the drafts:
  - No-infer: any field the tool couldn't verify shows "—" / "not provided", never guessed.
  - PII discipline: entity + contact name/email OK in Slack (internal channel);
    NO account numbers, NO SSNs, no sensitive doc contents in the ping.

### STANDING PRINCIPLE (Shani) — "let the ops rep decide"
When a design choice is between (a) the tool acting/committing on its own and (b) the
tool surfacing the situation + evidence and letting the rep choose, DEFAULT TO (b).
Stop re-asking on these; pick the rep-decides option automatically. The tool's job is
to tee up the decision (draft it, show the evidence, name what's unknown), not to make
the call. This is just the no-infer + "human touchpoints are approvals" principle applied
to every fork. Reserve confirmation questions for things that change the PROCESS, not
for UI/wording defaults.

Applied to intake Slack pings:
- Ping A: show it, open the case on clean signal, but the rep's ACTION (send Application
  Form) stays a rep decision in-app. Keep the ambiguous variant (asks before acting).
- Ping B: auto-draft the Jira ticket, rep clicks Confirm to create (never auto-create).
  Include a link to the #csfraud post so the rep can see/decide on fraud status too,
  rather than the tool asserting fraud is "handled."
