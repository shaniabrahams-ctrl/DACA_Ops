# Claude Code prompt — DACA Ops intake stage (Slack notifications)

Paste everything below the line into the Claude Code session.

---

Read `docs/SESSION_2026-07-22_HANDOFF.md` and `.claude/skills/daca-ops-tool/SKILL.md`
first. This is a scoped change to the **intake stage only** — do not touch downstream
stages, and do not modify `src/register/lifecycle.py` stages or transition rules. This
is behavior + notification wiring, not a state-machine rework.

## Context (decisions already made with the DACA owner)
A DACA request enters via one funnel: whatever the channel (phone/email/web), Client
Service replies to the client and CCs `daca@rho.co` (a Google Group with the internal
DACA stakeholders). That CC is the universal capture point. Real example this is modeled
on: Zendesk #264554 → #265034 (Harmonate / Austin Walkup). One DACA case can span
multiple Zendesk tickets (a follow-up ticket cross-links the original); group them into
ONE register case.

Two Slack notifications to `#daca-ops` are the deliverable:

### Ping A — net-new inquiry detected (informational, auto)
- Trigger: an inbound thread with `daca@rho.co` CC'd, detected as net-new.
- CLEAN signal (subject/body clearly a DACA request AND no matching open case in the
  register): auto-open the case (this already happens in `sync_email_intake`) and post
  Ping A with NO action button — it's an FYI. Fields: business/entity, contact
  (name+email), origin (zendesk # + channel + CS rep, or direct email), lender
  (show "not provided yet" — never guess), arrived-at, link to thread, link to case.
- AMBIGUOUS signal (no "DACA" in subject, or a possible match to an existing case, or
  entity only inferable from a domain): DO NOT open a case or assert net-new. Post an
  "possible new request — confirm?" message WITH Yes(open case)/No(existing) buttons and
  wait. No silent action. (This is the no-infer rule.)

### Ping B — Application Form submitted (actionable)
- Trigger: a NEW ROW appears in the Typeform responses source matched to a case
  (Typeform is the source of truth for "client submitted the DACA Application Form").
- On submission, do two things and report both:
  1. Post the fraud-review request to the `#csfraud` channel asking the fraud team to
     review. This runs IN PARALLEL and must NOT block or gate anything. Include the
     #csfraud link in Ping B so the rep can check it.
  2. Stage a DRAFTED DACA Jira ticket — do NOT create it automatically. Ping B carries a
     "Confirm & create Jira ticket" button. The rep confirms from Slack OR the app; the
     create must be IDEMPOTENT (one ticket regardless of where/how many times clicked).

## Guardrails (must hold)
- No-infer: any field the tool can't verify shows "not provided"/"—", never a guess.
  Borrower legal entity, lender, and account are never inferred from an email.
- PII: entity + contact name/email may appear in these internal channels; NEVER account
  numbers, SSNs, or sensitive document contents.
- Idempotent: re-running intake or re-clicking confirm never duplicates a case, a ping,
  or a Jira ticket. Use idempotency keys consistent with the existing event log.
- "Rep decides" default: where the choice is tool-acts vs. rep-chooses, surface the
  situation + evidence and let the rep choose. Reserve auto-action for clean, unambiguous
  signals only.
- Canonical client-facing name is "DACA Application Form".

## Where the code already is (extend these — don't recreate)
- `src/register/intake_email.py` — `sync_email_intake()` already turns a CC'd inquiry
  into a net-new `inquiry`-stage case, idempotently, and returns `{created: [...]}`.
  Ping A should fire off the `created` list. Add the ambiguous-vs-clean split here (right
  now it creates on any thread with a requester; it needs a net-new confidence check that
  routes ambiguous ones to a confirm-ping instead of auto-creating).
- `src/integrations/slack_notify.py` — already has `configured()`, `format_new_request()`,
  and `post(text, channel)`. Extend it: add block-kit style messages with fields + action
  buttons for Ping A (clean + ambiguous variants) and Ping B, and a `#csfraud` post. Keep
  the "never raise on a config gap" behavior.
- `src/integrations/typeform_client.py` — the Typeform responses source. Add/use
  new-row detection to fire Ping B. (Confirm the actual module path; it's under
  `src/integrations/`, not `src/context/sources/`.)
- Jira create + confirm handler — wire the "Confirm & create Jira ticket" action
  (in-app and Slack) to a single idempotent create path.

## Definition of done (test before claiming complete)
1. Feed `sync_email_intake` the Harmonate thread (entity "Harmonate", requester
   awalkup@harmonate.com, subject "DACA Inquiry | Rho", zendesk #264554) → one case
   created, one Ping A composed with correct fields and lender = "not provided yet".
2. Feed an ambiguous thread (subject with no "DACA", domain-only entity) → NO case
   created, a confirm-ping composed with Yes/No actions.
3. Simulate a new Typeform row for that case → Ping B composed with the #csfraud link and
   a staged (not created) Jira ticket + confirm action.
4. Re-run all three → no duplicate cases, pings, or tickets (idempotency holds).
5. `format_*` functions return valid Slack payloads; `post()` still no-ops cleanly when
   Slack isn't configured. Show the composed payloads in test output as evidence.

Start by reading the two docs and the three source files above, tell me the actual
`typeform_client.py` path and current `slack_notify.py` block structure, propose the
net-new confidence check, then implement. Show test output for all 5 done-criteria before
saying it's done.
